
#pragma once

#include "ofxPDSP.h"


class EFFDelayUnit  {
public:
    
    pdsp::Delay* delayL;
    pdsp::Delay* delayR;
    pdsp::Amp*               delaySend;
    
    ofParameter<float> _e_delay_in_send;
    ofParameter<float> _e_delay_in_sendMin;
    ofParameter<float> _e_delay_in_sendMax;
    ofParameter<int> _e_delay_in_sendConnectTo;
    
    ofParameter<float> _e_delay_in_time;
    ofParameter<float> _e_delay_in_timeMin;
    ofParameter<float> _e_delay_in_timeMax;
    ofParameter<int> _e_delay_in_timeConnectTo;
    
    ofParameter<float> _e_delay_in_damping;
    ofParameter<float> _e_delay_in_dampingMin;
    ofParameter<float> _e_delay_in_dampingMax;
    ofParameter<int> _e_delay_in_dampingConnectTo;
    
    ofParameter<float> _e_delay_in_feedback;
    ofParameter<float> _e_delay_in_feedbackMin;
    ofParameter<float> _e_delay_in_feedbackMax;
    ofParameter<int> _e_delay_in_feedbackConnectTo;
    

    
    ofParameterGroup ParamGroup;
    bool usesSend =true;
    bool isMono = true;
    
    void setup(){
        ParamGroup.add(_e_delay_in_send.set("Send ", 0.0, 0, 1));
        ParamGroup.add(_e_delay_in_sendMin.set("Send Min", 0.0, 0, 1));
        ParamGroup.add(_e_delay_in_sendMax.set("Send Max", 1.0, 0, 1));
        ParamGroup.add(_e_delay_in_sendConnectTo.set("Send Connect To", 0, 0, 6));
        
        ParamGroup.add(_e_delay_in_time.set("Time ", 0.0, 0.0, 20));
        ParamGroup.add(_e_delay_in_timeMin.set("Time Min", 0.0, 0.0, 200));
        ParamGroup.add(_e_delay_in_timeMax.set("Time Max", 200, 0.0, 200));
        ParamGroup.add(_e_delay_in_timeConnectTo.set("Time Connect To", 0, 0, 6));
        
        ParamGroup.add(_e_delay_in_damping.set("Damping ", 0.0, 0, 1));
        ParamGroup.add(_e_delay_in_dampingMin.set("Damping Min", 0.0, 0, 1));
        ParamGroup.add(_e_delay_in_dampingMax.set("Damping Max", 1.0, 0, 1));
        ParamGroup.add(_e_delay_in_dampingConnectTo.set("Damping Connect To", 0, 0, 6));
        
        ParamGroup.add(_e_delay_in_feedback.set("feedback ", 0.0, 0, 1));
        ParamGroup.add(_e_delay_in_feedbackMin.set("feedback Min", 0.0, 0, 1));
        ParamGroup.add(_e_delay_in_feedbackMax.set("feedback Max", 1.0, 0, 1));
        ParamGroup.add(_e_delay_in_feedbackConnectTo.set("feedback COnnect To", 0, 0, 6));
        
    }
    
    ofParameterGroup getParamGroup(){
        
        return ParamGroup;
    }
    
    bool getIsMono(){
        return isMono;
    }
    
    void setParameterGroupName(std::string name){
        ParamGroup.setName(name);
    }
    
    pdsp::Amp* getSendObject(){
        return delaySend;
    }
    pdsp::Delay* geteffectObjectL(){
        
        return delayL;
    }
    pdsp::Delay* geteffectObjectR(){
        
        return delayR;
    }
    
    bool getUsesSend(){
        return usesSend;
    }
    
    void exit() {
        
        ofLogVerbose()<<"MyTestObject::exit() - goodbye!\n"<<endl;
    }
    
    
    void update() {
        
        _e_delay_in_send >> delaySend->in_mod();
        
        _e_delay_in_time >> delayL->in_time();
        _e_delay_in_damping >> delayL->in_damping();
        _e_delay_in_feedback >> delayL->in_feedback();
        
        _e_delay_in_time >> delayR->in_time();
        _e_delay_in_damping >> delayR->in_damping();
        _e_delay_in_feedback >> delayR->in_feedback();
   
    }
    
    
    void draw() {
        
        
        
    }
    
    
};
