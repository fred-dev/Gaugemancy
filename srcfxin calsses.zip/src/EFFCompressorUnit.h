
#pragma once

#include "ofxPDSP.h"


class EFFCompressorUnit  {
public:
    
    pdsp::Compressor* compressor;
    
    ofParameter<int> _e_compressor_in_attack;
    ofParameter<float> _e_compressor_in_knee;
    ofParameter<int> _e_compressor_in_ratio;
    ofParameter<int> _e_compressor_in_release;
    ofParameter<float> _e_compressor_in_threshold;
    
    
    ofParameterGroup ParamGroup;
    
    bool usesSend = false;
    bool isMono = false;
    
    
    void setup(){
        ParamGroup.add(_e_compressor_in_attack.set("Attack", 0, 0, 200));
        ParamGroup.add(_e_compressor_in_knee.set("Knee", 0, 0, 1));
        ParamGroup.add(_e_compressor_in_ratio.set("Ratio", 0, 0, 10));
        ParamGroup.add(_e_compressor_in_release.set("Release", 0, 0, 200));
        ParamGroup.add(_e_compressor_in_threshold.set("Threshold", 0, 0, 1));
  
    }
    
    void setParameterGroupName(std::string name){
        ParamGroup.setName(name);
    }
    ofParameterGroup getParamGroup(){
        return ParamGroup;
    }
    
    pdsp::Compressor* geteffectObject(){
        return compressor;
    }
    
    bool getUsesSend(){
        return usesSend;
    }
    
    bool getIsMono(){
        return isMono;
    }
    
    void exit() {
        
    }
    
    
    void update() {
        _e_compressor_in_attack >> compressor->in_attack();
        _e_compressor_in_knee >> compressor->in_knee();
        _e_compressor_in_ratio >> compressor->in_ratio();
        _e_compressor_in_release >> compressor->in_release();
        _e_compressor_in_threshold >> compressor->in_threshold();
        
    }


};
