
#pragma once

#include "ofxPDSP.h"


class EFFFilterUnit  {
public:
    
    pdsp::MultiLadder4* multiLadderFilterL;
    pdsp::MultiLadder4* multiLadderFilterR;
    ofParameter<int> _e_MLAD_in_freq;
    ofParameter<int> _e_MLAD_in_freqMin;
    ofParameter<int> _e_MLAD_in_freqMax;
    ofParameter<int> _e_MLAD_in_freqConnectTo;
    
    ofParameter<float> _e_MLAD_in_reso;
    ofParameter<float> _e_MLAD_in_resoMin;
    ofParameter<float> _e_MLAD_in_resoMax;
    ofParameter<int> _e_MLAD_in_resoConnectTo;
    
    ofParameterGroup ParamGroup;
    
    bool usesSend = false;
    bool isMono = true;
    
    
    void setup(){
        ParamGroup.add(_e_MLAD_in_freq.set("Freq", 0, 0, 20000));
        ParamGroup.add(_e_MLAD_in_freqMin.set("Freq Min", 0, 0, 20000));
        ParamGroup.add(_e_MLAD_in_freqMax.set("Freq Max", 20000, 0, 20000));
        ParamGroup.add(_e_MLAD_in_freqConnectTo.set("Freq connect to", 0, 0, 6));
        
        ParamGroup.add(_e_MLAD_in_reso.set("Reso", 0, 0, 1));
        ParamGroup.add(_e_MLAD_in_resoMin.set("Reso Min", 0, 0, 1));
        ParamGroup.add(_e_MLAD_in_resoMax.set("Reso Max", 1, 0, 1));
        ParamGroup.add(_e_MLAD_in_resoConnectTo.set("Reso connect to", 0, 0, 6));
    }
    
    void setParameterGroupName(std::string name){
        ParamGroup.setName(name);
    }
    ofParameterGroup getParamGroup(){
        return ParamGroup;
    }
    
    pdsp::MultiLadder4* geteffectObjectL(){
        return multiLadderFilterL;
    }
    
    pdsp::MultiLadder4* geteffectObjectR(){
        return multiLadderFilterR;
    }
    
    bool getUsesSend(){
        return usesSend;
    }
    
    bool getIsMono(){
        return isMono;
    }
    
    void exit() {
        
    }
    
    
    void update() {
        _e_MLAD_in_freq >> multiLadderFilterL->in_freq();
        _e_MLAD_in_reso >> multiLadderFilterL->in_reso();
        
        _e_MLAD_in_freq >> multiLadderFilterR->in_freq();
        _e_MLAD_in_reso >> multiLadderFilterR->in_reso();
    }


};
